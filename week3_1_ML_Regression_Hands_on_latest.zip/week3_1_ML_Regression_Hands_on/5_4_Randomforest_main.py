#load and call the model for input.

#loading the saved model using pickle
import pickle
loaded_model2=pickle.load(open(r"C:\AI_Learing_Folder\SLR\final_random_forest_model.sav",'rb'))

Inp=[[200000,50000,100000,0,0]]
result=loaded_model2.predict(Inp)

print(result)

'''
Output:
(.venv) PS C:\AI_Learing_Folder\SLR> python 5_4_Randomforest_main.py
C:\AI_Learing_Folder\SLR\.venv\Lib\site-packages\sklearn\utils\validation.py:2691: UserWarning: X does not have valid feature names, but RandomForestRegressor was fitted with feature names
  warnings.warn(
[165994.5618]
'''
