#1. Collect/load data
import pandas as pd
dataset = pd.read_csv(r"C:\AI_Learing_Folder\SLR\Multilinear_regression\50_startups.csv")
#print(dataset)

#2.extend the state column using get dummies function
dataset=pd.get_dummies(dataset,drop_first=True)
#print(dataset)

#3.Split independent and dependent values
#print(dataset.columns)
independent=dataset[['R&D Spend', 'Administration', 'Marketing Spend','State_Florida', 'State_New York']]
dependent=dataset[['Profit']]
#print(independent)

#4. split training and test data
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(independent,dependent,test_size=0.30,random_state=0)

#5. Create the regression model
from sklearn.linear_model import LinearRegression
regressor_r2=LinearRegression()
regressor_r2.fit(x_train,y_train)

#6.Evaluate the model
weight=regressor_r2.coef_
print("Weight is", weight)
bias=regressor_r2.intercept_
print("bias is", bias)

from sklearn.metrics import r2_score
y_pred=regressor_r2.predict(x_test)
r_score=r2_score(y_test,y_pred)
print(r_score)

#6. Save the model
import pickle
file_name=r"C:\AI_Learing_Folder\SLR\Multilinear_regression\final_multilinear_regression_model.sav"
pickle.dump(regressor_r2,open(file_name,'wb'))
print("model saved successfully")