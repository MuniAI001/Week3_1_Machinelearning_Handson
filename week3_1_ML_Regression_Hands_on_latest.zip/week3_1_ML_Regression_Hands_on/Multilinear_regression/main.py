import os, pickle

file_path=r"C:\AI_Learing_Folder\SLR\Multilinear_regression\final_multilinear_regression_model.sav"

loaded_model_m2=pickle.load(open(file_path,'rb'))

Inp=[[200000,50000,100000,0,0]]
result=loaded_model_m2.predict(Inp)

print(result)