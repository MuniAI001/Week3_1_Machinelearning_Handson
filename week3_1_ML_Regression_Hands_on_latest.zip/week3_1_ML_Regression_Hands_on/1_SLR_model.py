import pandas as pd

#1.Collect the data
dataset = pd.read_csv("C:\AI_Learing_Folder\SLR\Salary_Data.csv")
#print(dataset)

#2.split independent and dependent values.
independent=dataset[["YearsExperience"]]
dependent=dataset[["Salary"]]
# print(independent)
# print(dependent)

#3.split the training and test dataset
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(independent,dependent,test_size=.30,random_state=0)
print(x_train)

#4.Create model using train dataset.
from sklearn.linear_model import LinearRegression
regressor_r1=LinearRegression()
regressor_r1.fit(x_train,y_train)

#5.Evaluate the model
print("weight is",regressor_r1.coef_)
print("bias is",regressor_r1.intercept_)
y_pred=regressor_r1.predict(x_test)
from sklearn.metrics import r2_score
r_score=r2_score(y_test,y_pred)
print("r_score is",r_score)

#6.Save the model
import pickle
filename=r"C:\AI_Learing_Folder\SLR\final_regression_model.sav"
pickle.dump(regressor_r1,open(filename,'wb'))
print("model loaded successfully")

#7.Load the model
'''we do it in main.py'''