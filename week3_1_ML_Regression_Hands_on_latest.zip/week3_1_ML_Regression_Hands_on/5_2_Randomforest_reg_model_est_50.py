#5_2_Randomforest_reg_model_est_50.py

#1. Collect/load data
import pandas as pd
dataset = pd.read_csv(r"C:\AI_Learing_Folder\SLR\50_startups.csv")
#print(dataset)

#2.extend the state column using get dummies function
dataset=pd.get_dummies(dataset,drop_first=True)
#print(dataset)

#3.Split independent and dependent values
#print(dataset.columns)
independent=dataset[['R&D Spend', 'Administration', 'Marketing Spend','State_Florida', 'State_New York']]
dependent=dataset[['Profit']]
#print(independent)

#4. split training and test data
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(independent,dependent,test_size=0.30,random_state=0)

# #4.1 Standardization
# from sklearn.preprocessing import StandardScaler
# sc=StandardScaler()
# x_train=sc.fit_transform(x_train)
# x_test=sc.transform(x_test)

#5. Create the regression model
from sklearn.ensemble import RandomForestRegressor
regressor_s1=RandomForestRegressor(n_estimators=10,criterion='squared_error')
regressor_s1.fit(x_train,y_train)

regressor_s2=RandomForestRegressor(n_estimators=10,criterion='absolute_error')
regressor_s2.fit(x_train,y_train)

regressor_s3=RandomForestRegressor(n_estimators=10,criterion='friedman_mse')
regressor_s3.fit(x_train,y_train)

regressor_s4=RandomForestRegressor(n_estimators=10,criterion='poisson')
regressor_s4.fit(x_train,y_train)

#6.Evaluate the model
from sklearn.metrics import r2_score
y_pred1=regressor_s1.predict(x_test)
s1_score=r2_score(y_test,y_pred1)
print("s1_score is ", s1_score)

y_pred2=regressor_s2.predict(x_test)
s2_score=r2_score(y_test,y_pred2)
print("s2_score is ", s2_score)

y_pred3=regressor_s3.predict(x_test)
s3_score=r2_score(y_test,y_pred3)
print("s3_score is ", s3_score)

y_pred4=regressor_s4.predict(x_test)
s4_score=r2_score(y_test,y_pred4)
print("s4_score is ", s4_score)

'''
output:
s1_score is  0.22662731078445952
s2_score is  0.9377394801743579
s3_score is  0.8212809573774871
s4_score is  0.626409422505467

'''

#6. Save the model
# import pickle
# file_name=r"C:\AI_Learing_Folder\SLR\Multilinear_regression\final_multilinear_regression_model.sav"
# pickle.dump(regressor_r2,open(file_name,'wb'))
# print("model saved successfully")
