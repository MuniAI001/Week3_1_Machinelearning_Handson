#load and call the model for input.

#loading the saved model using pickle
import pickle
loaded_model=pickle.load(open(r"C:\AI_Learing_Folder\SLR\final_regression_model.sav",'rb'))

#receive the experience as user input
Exp = int(input("Enter the Exp"))

#populates the salary for the give experince using our model 
result=loaded_model.predict([[Exp]])
print("Qualified Salary is ",result)
